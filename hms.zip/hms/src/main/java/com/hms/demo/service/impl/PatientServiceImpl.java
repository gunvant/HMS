package com.hms.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.demo.exception.PatientNotFoundException;
import com.hms.demo.model.Patient;
import com.hms.demo.repository.PatientRepository;
import com.hms.demo.service.PatientService;


@Service
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	private PatientRepository patientRepository;
	
	
	public Patient save(Patient patient) {
		return patientRepository.save(patient);
	}
	
	public List<Patient> findAll() {
		return (List<Patient>) patientRepository.findAll();
	}
	
	public Optional<Patient> findOne(Long id) throws PatientNotFoundException {
		Optional<Patient> patient=patientRepository.findById(id);
				
		if(patient.isEmpty()) {
			throw new PatientNotFoundException("Patient "+id+" not found");
		}
		
		return patient; 
	}
	
	public void removeOne(Long id) throws PatientNotFoundException {
		if(!patientRepository.existsById(id)) {
			throw new PatientNotFoundException("Patient "+id+" not found");
		}
		patientRepository.deleteById(id);
	}
	
	
}
