package com.hms.demo.service;

import java.util.List;
import java.util.Optional;

import com.hms.demo.exception.PatientNotFoundException;
import com.hms.demo.model.Patient;



public interface PatientService {

	Patient save(Patient patient);

	List<Patient> findAll();
	
	Optional<Patient> findOne(Long id) throws PatientNotFoundException;
	
	void removeOne(Long id) throws PatientNotFoundException;
}
