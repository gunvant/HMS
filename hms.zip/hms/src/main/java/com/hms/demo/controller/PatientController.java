package com.hms.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hms.demo.exception.PatientNotFoundException;
import com.hms.demo.model.Patient;
import com.hms.demo.service.PatientService;


/**
 * Documentation about Patient API's
 * @author Gunavant Jambu
 *
 */

@RestController
@RequestMapping("/patient")
public class PatientController {
	
	private static final Logger logger = LoggerFactory.getLogger(PatientController.class);


	@Autowired
	private PatientService patientService;	
	

	
	/**
	 * API to add Patient
	 * @param patient
	 * @return
	 */
	@PostMapping(value = "/add")
	public Patient addPatientPost(@Valid @RequestBody Patient patient) {
				
		patientService.save(patient);				
		
		logger.info("Patient is saved Successfully. Patient Id"+patient.getId());
		
		return patient;
		
	}		
		
	/**
	 * API To get all patient
	 * @return
	 */
	@GetMapping("/all")
	public List<Patient> patientList() {
		
		List<Patient> patientList = patientService.findAll();
		
		logger.info("Fetch all patients "+patientList.size());
		
		return patientList;
		
	}
	
	/**
	 * API to get patient by ID
	 * 
	 * 
	 * @param id
	 * @return
	 * @throws PatientNotFoundException
	 */
	@GetMapping("/{id}")
	public Patient findPateint(@PathVariable("id") String id) throws PatientNotFoundException {
		
		logger.info("Find Patient"+id);
		
		Optional<Patient> patient = patientService.findOne(Long.parseLong(id));
		
		return patient.get();
		
	}
	
	/**
	 * API to remove patient
	 * @param id
	 * @return
	 */
	@DeleteMapping("/{id}")
	public List<Patient> remove(@PathVariable("id") String id) throws PatientNotFoundException{
		
		patientService.removeOne(Long.parseLong(id));
		
		List<Patient> patientList = patientService.findAll();		
		
		return patientList;
		
	}
	
	

}
