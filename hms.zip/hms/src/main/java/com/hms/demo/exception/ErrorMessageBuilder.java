package com.hms.demo.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;

/**
 * Custom error message builder class
 * @author Gunavant Jambu
 *
 */
public class ErrorMessageBuilder {
	private String code;
	private String message;
	private Date timestamp;
	private HttpStatus status;
	private ErrorMessageBuilder() {
		this.timestamp=new Date();
	}
	
	public static ErrorMessageBuilder build() {
		return new ErrorMessageBuilder();
	}

	public String getCode() {
		return code;
	}

	public ErrorMessageBuilder setCode(String code) {
		this.code = code;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public ErrorMessageBuilder setMessage(String message) {
		this.message = message;
		return this;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public ErrorMessageBuilder setStatus(HttpStatus status) {
		this.status = status;
		return this;
	}

		
	
}
