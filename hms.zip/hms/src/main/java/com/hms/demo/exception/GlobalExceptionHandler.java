package com.hms.demo.exception;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	
	@ExceptionHandler(PatientNotFoundException.class)
	public ResponseEntity<ErrorMessageBuilder> handlePatientNotFoundException(HttpServletRequest request, Exception ex){
				ErrorMessageBuilder message=ErrorMessageBuilder.build()
															   .setCode("PT_NOT_FOUND")
															   .setMessage(ex.getMessage())
															   .setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
				return new ResponseEntity<ErrorMessageBuilder>(message,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="IOException occured")
	@ExceptionHandler(IOException.class)
	public ResponseEntity<ErrorMessageBuilder>  handleNoResourceFoundException(){
		ErrorMessageBuilder message=ErrorMessageBuilder.build()
				   .setCode("PAGE_NOT_FOUND")
				   .setMessage("Requested page not available");
		return new ResponseEntity<ErrorMessageBuilder>(message,HttpStatus.BAD_REQUEST);

	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessageBuilder> handleBadRequestException(Exception ex){
		ErrorMessageBuilder message=ErrorMessageBuilder.build()
				   .setCode("SOMETHING_WENT_WRONG")
				   .setMessage("Something went wrong");
		logger.error(ex.getMessage());
		ex.printStackTrace();
		return new ResponseEntity<ErrorMessageBuilder>(message,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>>  handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
	    Map<String, String> errors = new HashMap<String,String>();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return new ResponseEntity<Map<String, String>>(errors,HttpStatus.INTERNAL_SERVER_ERROR);

	}
}