package com.hms.demo.exception;

public class PatientNotFoundException extends Exception {

	public PatientNotFoundException(String message) {
		super(message);
	}

}
